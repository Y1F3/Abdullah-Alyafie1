# موقع عبدالله اليافعي — دليل النشر والتحديث

موقع ثابت (HTML + CSS + JS) بدون سيرفر أو قاعدة بيانات، ويعمل مجانًا على GitHub Pages.

## 1) النشر (مرة واحدة)
1. أنشئ حسابًا/ادخل على github.com (حسابك y1f3).
2. New repository ← اسمه `portfolio` ← Public ← Create.
3. اضغط **uploading an existing file** وارفع **محتويات** هذا المجلد (index.html و css و js و assets و robots.txt و sitemap.xml) ثم Commit.
4. من Settings ← Pages ← Source: **Deploy from a branch** ← Branch: `main` / `(root)` ← Save.
5. بعد دقيقة يظهر الرابط: `https://y1f3.github.io/portfolio/`

> إذا اخترت اسم مستودع غير `portfolio` غيّر الرابط في: index.html (canonical, og, twitter, JSON-LD) و robots.txt و sitemap.xml.
> لو سمّيت المستودع `y1f3.github.io` يصبح الرابط `https://y1f3.github.io/` مباشرة.

## 2) ما يجب أن تعدّله قبل النشر
- **الإيميل:** في index.html ابحث عن `YOUR-EMAIL@example.com`.
- **واتساب:** ابحث عن `971500000000` وضع رقمك بصيغة دولية بدون + أو أصفار.
- **السيرة الذاتية:** ضع ملف PDF باسم `cv.pdf` داخل مجلد `assets/`.
- **صورة الـHero:** `assets/images/hero.jpg` (عمودية 4:5 أفضل).
- **صورة المشاركة (OG):** `assets/images/og.jpg` بمقاس 1200×630.

## 3) إضافة الصور والمشاريع
افتح `js/projects.js`:
- ضع صورة المشروع في `assets/images/` ثم اكتب مسارها في `image`، مثل `"assets/images/afa.jpg"`.
- لإضافة مشروع جديد انسخ سطر مشروع كامل وعدّل بياناته.
- `category` يقبل: Photography, Video, Content, Interviews, On-Camera (يمكن أكثر من واحد).
- `video`: رابط YouTube أو Vimeo أو Instagram أو MP4 يظهر كزر "شاهد المشروع" (بدون تحميل فيديو ضخم).
- من نفس الملف تعدّل الخدمات وبطاقات "أمام/خلف الكاميرا".
- الأقسام التي بلا صورة تُظهر placeholder واضحًا حتى تضيف صورتك.

## 4) نصائح للأداء
حوّل الصور إلى WebP مجانًا عبر squoosh.app، وخلّ عرضها 1600px كحد أقصى (أقل من 300KB للصورة).

## 5) دومين خاص (لاحقًا)
Settings ← Pages ← Custom domain، وغيّر الروابط في الملفات المذكورة أعلاه.
