const $=s=>document.querySelector(s);
const esc=t=>String(t).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const cards=(el,list,desc)=>$(el).innerHTML=list.map(i=>`<div class="card"><h3>${esc(i[1])}</h3><span class="en">${esc(i[0])}</span>${desc?`<p>${esc(i[2])}</p>`:""}</div>`).join("");
cards("#services-grid",SERVICES,true);cards("#oncam-grid",ONCAM);cards("#behind-grid",BEHIND);

/* Portfolio + filters */
const cats=["All","Photography","Video","Content","Interviews","On-Camera"];
const fb=$(".filters"),wg=$("#works-grid");
function render(cat){
  wg.innerHTML=PROJECTS.filter(p=>cat==="All"||p.category.includes(cat)).map(p=>{
    const link=p.video||p.link;
    return `<article class="card work"><div class="ph" data-ph="ضع صورة ${esc(p.title)} هنا">${p.image?`<img src="${esc(p.image)}" alt="${esc(p.title)}" loading="lazy" decoding="async">`:""}</div>
    <div class="body"><div class="meta">${esc([p.org,p.year].filter(Boolean).join(" · "))}</div><h3>${esc(p.title)}</h3>
    <div class="meta">${esc(p.role)}</div><p>${esc(p.desc)}</p>${link?`<a class="more" href="${esc(link)}" target="_blank" rel="noopener">شاهد المشروع</a>`:""}</div></article>`}).join("");
}
fb.innerHTML=cats.map((c,i)=>`<button type="button" aria-pressed="${i==0}">${c}</button>`).join("");
fb.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
  fb.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed",x===b));render(b.textContent)});
render("All");

/* Mobile menu */
const bg=$(".burger"),menu=$("#menu");
const toggle=o=>{menu.classList.toggle("open",o);bg.setAttribute("aria-expanded",o)};
bg.onclick=()=>toggle(!menu.classList.contains("open"));
menu.addEventListener("click",e=>{if(e.target.tagName==="A")toggle(false)});

/* Reveal on scroll */
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}}),{threshold:.1});
document.querySelectorAll(".reveal").forEach(el=>io.observe(el));
