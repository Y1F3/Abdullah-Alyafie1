/* ===== عدّل هنا فقط لإضافة مشاريعك =====
   category: Photography | Video | Content | Interviews | On-Camera
   image: مسار الصورة (مثل "assets/images/ay-media.jpg") — اتركه "" لإظهار placeholder
   video: رابط YouTube / Vimeo / Instagram / MP4 (اختياري)   link: رابط المشروع (اختياري) */
const PROJECTS = [
 {title:"AY Media",org:"AY Media",year:"2022–الآن",role:"تصوير · إنتاج محتوى",category:["Photography","Video","Content"],desc:"مشاريع تصوير وإنتاج محتوى بصري للفعاليات والأشخاص والمشاريع، باستخدام التصوير الفوتوغرافي والفيديو.",image:"",video:"",link:"https://instagram.com/aymedia.ae"},
 {title:"AFA FTI Quattro",org:"AFA FTI Quattro",year:"2026",role:"محتوى · تصوير · سوشال ميديا",category:["Content","Photography","Video"],desc:"إنتاج محتوى رياضي وتوثيق التدريبات والمباريات واللاعبين، مع تصوير فوتوغرافي وفيديو وإدارة محتوى لمنصات التواصل.",image:"",video:"",link:""},
 {title:"Arabic Media Summit",org:"قمة الإعلام العربي",year:"2026",role:"تغطية إعلامية · تصوير",category:["Content","Photography","Interviews"],desc:"تغطية إعلامية وصناعة محتوى خلال قمة الإعلام العربي، شملت التصوير والتفاعل مع الجمهور وإنتاج محتوى للمنصات الرقمية.",image:"",video:"",link:""},
 {title:"New Media Academy — صُنّاع الأثر",org:"New Media Academy",year:"2026",role:"مشارك وخريج",category:["Content"],desc:"المشاركة في برنامج صُنّاع الأثر لصناعة المحتوى، والتخرج ضمن تجربة مرتبطة بقمة المليار متابع.",image:"",video:"",link:""},
 {title:"Government Communication Forum",org:"منتدى الاتصال الحكومي",year:"",role:"حضور وتغطية إعلامية",category:["Content","Photography"],desc:"حضور وتغطية إعلامية ضمن فعاليات الاتصال الحكومي.",image:"",video:"",link:""},
 {title:"Youth & Community Projects",org:"مبادرات شبابية ومجتمعية",year:"",role:"إنتاج وتوثيق",category:["Content","Video"],desc:"إنتاج وتوثيق محتوى لمبادرات ومشاريع شبابية ومجتمعية.",image:"",video:"",link:""},
 {title:"Advertising / On-Camera",org:"",year:"",role:"ممثل · صانع محتوى",category:["On-Camera"],desc:"الظهور في محتوى إعلاني وحملات مرئية، والعمل أمام الكاميرا كممثل وصانع محتوى.",image:"",video:"",link:""}
];
const SERVICES=[
 ["Content Creation","صناعة المحتوى","صناعة محتوى قصير ومرئي للمنصات الرقمية، من الفكرة إلى التصوير والتنفيذ."],
 ["Photography","التصوير الفوتوغرافي","تصوير الفعاليات، الأشخاص، السيارات، المنتجات، المشاريع والمناسبات."],
 ["Video Production","إنتاج الفيديو","تصوير وإخراج محتوى الفيديو والمشاريع المرئية."],
 ["Interviews & Hosting","التقديم والمقابلات","تقديم المقابلات والتغطيات والظهور أمام الكاميرا."],
 ["Acting & On-Camera","التمثيل والظهور","الظهور في الإعلانات والحملات والمحتوى التمثيلي."],
 ["Creative Ideas","تطوير الأفكار","تطوير أفكار المحتوى، السيناريوهات والمفاهيم البصرية."]];
const ONCAM=[["Presenting","التقديم"],["Interviews","المقابلات"],["Acting","التمثيل"],["Advertising","الإعلانات"],["Event Coverage","تغطية الفعاليات"],["Social Content","المحتوى الرقمي"]];
const BEHIND=[["Photography","التصوير"],["Videography","تصوير الفيديو"],["Directing","الإخراج"],["Editing","المونتاج"],["Creative Direction","الإدارة الإبداعية"],["Content Production","إنتاج المحتوى"]];
